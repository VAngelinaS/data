
def main():
    with open("in.txt", "r") as inputFile, open("out.txt", "w") as outputFile:
        lines = inputFile.readlines()
        i = 0
        while i < len(lines):
            name = lines[i].strip()
            start_date, end_date = lines[i+1].strip().split()
            day = int(end_date.split('.')[0]) - int(start_date.split('.')[0])
            month = int(end_date.split('.')[1]) - int(start_date.split('.')[1])
            year = int(end_date.split('.')[2]) - int(start_date.split('.')[2])

            if day < 0:
                month -= 1
                day += 30
            if month < 0:
                year -= 1
                month += 12

            output = f"{day} день" if day == 1 else f"{day} дня" if day < 5 else f"{day} дней"
            output += f" {month} месяц" if month == 1 else f" {month} месяца" if month < 5 else f" {month} месяцев"
            output += f" {year} год" if year == 1 else f" {year} года" if year < 5 else f" {year} лет"

            outputFile.write(f"{name}\n{output}\n")
            i += 2

if __name__ == "__main__":
    main()
