#include <stdio.h>
#include <locale.h>

int main(){
    FILE *inputFile, *outputFile;
    int day1, day2, mon1, mon2, year1, year2;
    setlocale(LC_ALL, "");

    inputFile = fopen("in.txt", "r");
    outputFile = fopen("out.txt", "w");

    if(fscanf(inputFile, "%d.%d.%d\n", &day1, &mon1, &year1) == 3 && fscanf(inputFile, "%d.%d.%d\n", &day2, &mon2, &year2) == 3){
        int day = day2 - day1;
        int month = mon2 - mon1;
        int year = year2 - year1;

        if(day < 0){
            month--;
            day += 30; 
        }

        if(month < 0){
            year--;
            month += 12;
        }
        
        
        if ((day > 1 && day < 5) || (day == 0)) {
            fprintf(outputFile, " %d дня", day);
        } else if (day == 1) {
            fprintf(outputFile, " %d день", day);
        } else {
            fprintf(outputFile, " %d дней", day);
        }

        if ((month > 1 && month < 5) || (month == 0)) {
            fprintf(outputFile, " %d месяца", month);
        } else if (month == 1) {
            fprintf(outputFile, " %d месяц", month);
        } else {
            fprintf(outputFile, " %d месяцев", month);
        }
        
        if (year > 4 || year == 0) {
            fprintf(outputFile, " %d лет", year);
        } else if (year == 1) {
            fprintf(outputFile, " %d год", year);
        } else {
            fprintf(outputFile, " %d года", year);
        }
    }

    fclose(inputFile);
    fclose(outputFile);

    return 0;
}